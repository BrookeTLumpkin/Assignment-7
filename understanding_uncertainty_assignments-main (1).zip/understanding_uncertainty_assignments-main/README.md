# Understanding Uncertainty Assignments


- Assignment 1: 9/5
- Assignment 2: 9/12-9/14
- Assignment 3: 9/23
- Assignment 4: 9/30
- Assignment 5: 10/23
- Assignment 6: 10/30
- Project 1: 11/13
- Assignment 7: 11/18
